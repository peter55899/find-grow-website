import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Find&Grow — Social Media Growth Agency" },
      {
        name: "description",
        content:
          "We build content systems and paid funnels that compound — taking brands from quiet feeds to consistent, measurable growth.",
      },
      { property: "og:title", content: "Find&Grow — Social Media Growth Agency" },
      {
        property: "og:description",
        content:
          "Content systems and paid funnels that compound. Turn followers into a revenue engine.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

/* ---------------------------------- data --------------------------------- */

const platforms = [
  {
    num: "01",
    name: "Instagram",
    desc: "Reels, carousels and DM funnels that turn scrollers into buyers.",
  },
  {
    num: "02",
    name: "TikTok",
    desc: "Short-form hooks and trend content that rack up real views.",
  },
  {
    num: "03",
    name: "YouTube",
    desc: "Shorts plus long-form that keeps compounding month after month.",
  },
  {
    num: "04",
    name: "Facebook",
    desc: "Community, groups and retargeting that drive repeat sales.",
  },
];

const rates = [
  {
    platform: "YouTube",
    items: [
      { label: "Subscriber 100", price: "Rs 250" },
      { label: "4k Watchtime Hours", price: "Rs 2,500" },
      { label: "Likes 1k", price: "Rs 350" },
      { label: "Subscriber 1k", price: "Rs 1,800" },
    ],
  },
  {
    platform: "Instagram",
    items: [
      { label: "Followers 1k", price: "Rs 250" },
      { label: "Followers 10k", price: "Rs 1,800" },
      { label: "Likes 1k", price: "Rs 80" },
      { label: "Views 1k", price: "Rs 40" },
      { label: "Comments 1k", price: "Rs 500" },
    ],
  },
  {
    platform: "Facebook",
    items: [
      { label: "Views 1k", price: "Rs 100" },
      { label: "Likes 1k", price: "Rs 100" },
      { label: "Followers 1k", price: "Rs 400" },
      { label: "Followers 10k", price: "Rs 2,000" },
    ],
  },
  {
    platform: "TikTok",
    items: [
      { label: "Views 10k", price: "Rs 100" },
      { label: "Likes 1k", price: "Rs 100" },
      { label: "Followers 1k", price: "Rs 400" },
      { label: "Followers 10k", price: "Rs 2,000" },
    ],
  },
];

const stats = [
  { value: "2.4M+", label: "followers gained for clients" },
  { value: "18x", label: "average return on paid social" },
  { value: "92%", label: "of clients renew after month three" },
  { value: "40+", label: "brands grown across 6 niches" },
];

const plans = [
  {
    name: "Starter",
    price: "Rs 350,000/mo",
    features: [
      "2 platforms",
      "12 posts per month",
      "Monthly growth report",
      "Email support",
    ],
    featured: false,
  },
  {
    name: "Scale",
    price: "Rs 800,000/mo",
    features: [
      "4 platforms",
      "30 posts + 8 reels per month",
      "Weekly strategy calls",
      "Paid ads management",
    ],
    featured: true,
  },
  {
    name: "Dominator",
    price: "Rs 1,550,000/mo",
    features: [
      "All platforms",
      "Daily content + paid ads",
      "Dedicated growth lead",
      "Same-day responses",
    ],
    featured: false,
  },
];

const testimonials = [
  {
    quote:
      "Our page went from 4k to 90k followers in 90 days, and the DMs are full of ready-to-buy customers.",
    author: "Maya Okafor — Founder, Lumen Skincare",
  },
  {
    quote:
      "They feel like part of the team, not a vendor. The reels just work.",
    author: "Devon Reyes — Founder, Loom & Thread",
  },
  {
    quote:
      "Inbound leads are up 3x since we started. Best marketing spend we've made.",
    author: "Priya Nand — CMO, Fieldnote",
  },
];

/* --------------------------------- page ---------------------------------- */

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <Platforms />
        <Rates />
        <Results />
        <Pricing />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <a href="#" className="font-display text-lg font-bold tracking-tight">
          Find<span className="text-primary">&</span>Grow
        </a>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#services" className="transition-colors hover:text-foreground">
            Services
          </a>
          <a href="#results" className="transition-colors hover:text-foreground">
            Results
          </a>
          <a href="#rates" className="transition-colors hover:text-foreground">
            Rates
          </a>
          <a href="#pricing" className="transition-colors hover:text-foreground">
            Pricing
          </a>
        </nav>
        <a
          href="#contact"
          className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105"
        >
          Start growing
        </a>
      </div>
    </header>
  );
}

function Hero() {
  const bars = [28, 45, 62, 80, 100];
  return (
    <section className="border-b border-border">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 lg:grid-cols-[1.4fr_1fr] lg:py-28">
        <div>
          <p className="font-display text-sm font-semibold tracking-[0.25em] text-primary uppercase">
            Social media growth agency
          </p>
          <h1 className="mt-5 font-display text-5xl leading-[1.05] font-bold tracking-tight sm:text-6xl lg:text-7xl">
            Turn followers into
            <br />a <span className="text-primary lime-glow">revenue engine</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            We build content systems and paid funnels that compound — taking
            brands from quiet feeds to consistent, measurable growth.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="rounded-full bg-primary px-7 py-3.5 font-display font-semibold text-primary-foreground transition-transform hover:scale-105"
            >
              Book a free growth audit
            </a>
            <a
              href="#results"
              className="rounded-full border border-input bg-card px-7 py-3.5 font-display font-semibold transition-colors hover:bg-accent"
            >
              See the numbers
            </a>
          </div>
        </div>
        <div className="rounded-3xl border border-border bg-card p-8">
          <p className="font-display text-xs font-semibold tracking-[0.25em] text-muted-foreground uppercase">
            Avg. follower growth
          </p>
          <p className="mt-3 font-display text-6xl font-bold text-primary lime-glow">
            +312%
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            across 12-month client retainers
          </p>
          <div className="mt-8 flex h-32 items-end gap-3">
            {bars.map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t-lg"
                style={{
                  height: `${h}%`,
                  backgroundColor:
                    i >= 3
                      ? "oklch(0.87 0.23 130)"
                      : "oklch(0.28 0.012 150)",
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Platforms() {
  return (
    <section id="services" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Every platform, one system
          </h2>
          <p className="text-muted-foreground">Pick a lane or go full-stack</p>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {platforms.map((p) => (
            <div
              key={p.name}
              className="card-hover rounded-2xl border border-border bg-card p-7"
            >
              <p className="font-display text-sm font-semibold text-primary">
                {p.num}
              </p>
              <h3 className="mt-4 font-display text-2xl font-semibold">
                {p.name}
              </h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Rates() {
  return (
    <section id="rates" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Services & rates
          </h2>
          <p className="text-muted-foreground">
            Per-order rates in PKR — bulk deals available
          </p>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {rates.map((group) => (
            <div
              key={group.platform}
              className="rounded-2xl border border-border bg-card p-7"
            >
              <h3 className="font-display text-2xl font-semibold">
                {group.platform}
              </h3>
              <ul className="mt-5 space-y-3">
                {group.items.map((item) => (
                  <li
                    key={item.label}
                    className="flex items-center justify-between gap-3 border-b border-border pb-3 text-sm last:border-0 last:pb-0"
                  >
                    <span className="text-muted-foreground">{item.label}</span>
                    <span className="font-display font-semibold whitespace-nowrap text-primary">
                      {item.price}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-10 text-center text-muted-foreground">
          Koi package ya custom order chahiye?{" "}
          <a href="#contact" className="font-medium text-primary hover:underline">
            Hum se baat karein
          </a>
        </p>
      </div>
    </section>
  );
}

function Results() {
  return (
    <section id="results" className="border-b border-border bg-card/40">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Results you can put in a deck
        </h2>
        <p className="mt-4 text-muted-foreground">
          We report on revenue, not vanity metrics.
        </p>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-border bg-card p-8 text-center"
            >
              <p className="font-display text-5xl font-bold text-primary lime-glow">
                {s.value}
              </p>
              <p className="mt-3 text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Pick your pace
        </h2>
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={
                plan.featured
                  ? "card-hover relative rounded-3xl border-2 border-primary bg-card p-8"
                  : "card-hover relative rounded-3xl border border-border bg-card p-8"
              }
            >
              {plan.featured && (
                <span className="absolute -top-3 left-8 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Most picked
                </span>
              )}
              <h3 className="font-display text-2xl font-semibold">{plan.name}</h3>
              <p className="mt-4 font-display text-3xl font-bold text-primary">
                {plan.price}
              </p>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex gap-3 text-sm">
                    <span className="text-primary">✓</span>
                    <span className="text-muted-foreground">{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href="#contact"
                className={
                  plan.featured
                    ? "mt-8 block rounded-full bg-primary px-6 py-3 text-center font-display font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
                    : "mt-8 block rounded-full border border-input px-6 py-3 text-center font-display font-semibold transition-colors hover:bg-accent"
                }
              >
                Choose {plan.name}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="border-b border-border bg-card/40">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Kind words
        </h2>
        <div className="mt-12 grid gap-5 lg:grid-cols-3">
          {testimonials.map((t) => (
            <blockquote
              key={t.author}
              className="rounded-2xl border border-border bg-card p-8"
            >
              <p className="leading-relaxed">“{t.quote}”</p>
              <footer className="mt-6 font-display text-sm font-semibold text-primary">
                {t.author}
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Let's build your growth engine
          </h2>
          <p className="mt-4 text-muted-foreground">
            Tell us where you are and where you want to be. We'll reply
            within one business day with an honest read.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-6 text-sm">
            <a
              href="mailto:info@find&grow.com"
              className="font-display font-semibold text-primary hover:underline"
            >
              info@find&grow.com
            </a>
            <a
              href="tel:+923244960506"
              className="font-display font-semibold text-primary hover:underline"
            >
              0324 4960506
            </a>
          </div>
        </div>
        <form
          className="mx-auto mt-12 max-w-xl space-y-5"
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
        >
          {sent ? (
            <div className="rounded-2xl border border-primary/40 bg-card p-8 text-center">
              <p className="font-display text-2xl font-semibold text-primary">
                Message sent!
              </p>
              <p className="mt-2 text-muted-foreground">
                Hum ek business day mein reply karenge.
              </p>
            </div>
          ) : (
            <>
              <div className="grid gap-5 sm:grid-cols-2">
                <input
                  required
                  placeholder="Your name"
                  className="w-full rounded-xl border border-input bg-card px-4 py-3.5 text-sm outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-primary"
                />
                <input
                  required
                  type="email"
                  placeholder="Email"
                  className="w-full rounded-xl border border-input bg-card px-4 py-3.5 text-sm outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-primary"
                />
              </div>
              <textarea
                required
                rows={5}
                placeholder="What are you trying to grow?"
                className="w-full rounded-xl border border-input bg-card px-4 py-3.5 text-sm outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-primary"
              />
              <button
                type="submit"
                className="w-full rounded-full bg-primary px-7 py-4 font-display font-semibold text-primary-foreground transition-transform hover:scale-[1.01]"
              >
                Send it over
              </button>
            </>
          )}
        </form>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-8 text-sm text-muted-foreground">
        <p className="font-display font-bold text-foreground">
          Find<span className="text-primary">&</span>Grow
        </p>
        <p>© {new Date().getFullYear()} Find&Grow. All rights reserved.</p>
      </div>
    </footer>
  );
}
